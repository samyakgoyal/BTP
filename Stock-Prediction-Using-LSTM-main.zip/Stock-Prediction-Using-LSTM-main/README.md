# Stock-Prediction-Using-LSTM
Predicting the opening cost of a stock based on the previous data using LSTM
